//Tally Szakel & Erin Stewart
package zoorassicpark;

public class MothMan extends LightsaberToothKlansman{
    
}
