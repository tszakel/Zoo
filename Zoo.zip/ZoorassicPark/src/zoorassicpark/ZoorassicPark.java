//Tally Szakel & Erin Stewart
package zoorassicpark;

import java.util.Scanner;

public class ZoorassicPark {

  
    public static void main(String[] args) {
        Scanner BOB = new Scanner(System.in);
        LightsaberToothKlansman Dave = new LightsaberToothKlansman();
            DerpSteve Steve = new DerpSteve();
            CavemanMancave Caveman = new CavemanMancave();
            MothMan Lamp = new MothMan();
        E Lee = new E();
            ScoobySans Scans = new ScoobySans();
            MemeMan Aaron = new MemeMan();
            DetectiveTHOT Gikachu = new DetectiveTHOT();
        DefaultKid Jake = new DefaultKid();
            ManagerMom Erin = new ManagerMom();
            KFurries Trish= new KFurries();
            DrPhilPatientZ BhadBabbie = new DrPhilPatientZ();
        
    }
    
}
