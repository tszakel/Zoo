//Tally Szakel & Erin Stewart
package zoorassicpark;

public class CavemanMancave extends LightsaberToothKlansman{
    
}
