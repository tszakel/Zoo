//Tally Szakel & Erin Stewart
package zoorassicpark;


public class ManagerMom extends DefaultKid{
    
}
