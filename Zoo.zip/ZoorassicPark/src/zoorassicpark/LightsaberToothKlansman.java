//Tally Szakel & Erin Stewart
package zoorassicpark;

public class LightsaberToothKlansman {
    getName
    String Oblivious = "Extremely";
    String Danger = "To myself";
    int lifespan = 20;
    
}
