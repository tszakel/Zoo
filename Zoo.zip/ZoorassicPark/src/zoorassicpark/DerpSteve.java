//Tally Szakel & Erin Stewart
package zoorassicpark;

public class DerpSteve extends LightsaberToothKlansman{
    
}
